# Portfolio — Dimas

Portofolio pribadi dengan tema **Neo Frutiger Aero** yang diinterpretasikan ulang secara modern: glassmorphism halus, gradient sky→emerald, dan motion yang bersih. Dibangun sebagai showcase publik di GitHub dan siap deploy ke Vercel.

![Status](https://img.shields.io/badge/status-selesai-34D8A6)
![Next.js](https://img.shields.io/badge/Next.js-16-black)
![TypeScript](https://img.shields.io/badge/TypeScript-strict-5EC8F2)

## ✨ Fitur

- **Hero** — komposisi tipografi besar tanpa foto profil, dengan horizon glass sebagai elemen visual khas
- **Tentang Saya** — narasi singkat berbasis data nyata (tidak ada info yang direkayasa)
- **Keahlian** — dikelompokkan per kategori (Frontend, AI, Tools, Currently Learning) tanpa progress bar/skill meter yang tak terbukti
- **Proyek** — kartu proyek reusable dengan empty state elegan saat data kosong; mudah diisi via `data/projects.ts`
- **Hobi** — presentasi minat di luar teknologi
- **Kontak** — CTA email + tautan sosial opsional, sepenuhnya data-driven
- Navbar mengambang dengan efek glass saat scroll
- Animasi scroll-reveal, hover lift, dan magnetic button (Framer Motion)
- Aksesibel: `prefers-reduced-motion` dihormati, fokus keyboard terlihat jelas
- SEO dasar: metadata, Open Graph, semantic HTML

## 🛠️ Tech Stack

- [Next.js 16](https://nextjs.org) (App Router) + TypeScript
- [Tailwind CSS v4](https://tailwindcss.com)
- [Framer Motion](https://www.framer.com/motion/)
- [Lucide React](https://lucide.dev) (ikon)

## 🚀 Menjalankan Secara Lokal

```bash
git clone https://github.com/<username>/portfolio.git
cd portfolio
npm install
npm run dev
```

Buka [http://localhost:3000](http://localhost:3000).

```bash
npm run build   # build production
npm run lint    # cek ESLint
```

## 📁 Struktur Folder

```
app/
  layout.tsx        # Root layout, font, metadata SEO
  page.tsx           # Komposisi seluruh section
  globals.css         # Design tokens & base style
components/
  sections/           # Section halaman (hero, about, skills, projects, hobbies, contact, navbar, footer)
  ui/                  # Komponen reusable (horizon-backdrop, magnetic-button, project-card, dll.)
data/
  projects.ts         # Data proyek — edit di sini untuk menambah proyek
  contact.ts          # Email & tautan sosial — edit di sini
lib/
  utils.ts             # Helper cn() untuk merge className
```

## ✍️ Mengisi Konten

**Menambah proyek** — edit `data/projects.ts`:

```ts
export const projects: Project[] = [
  {
    slug: "nama-proyek",
    title: "Nama Proyek",
    description: "Deskripsi singkat.",
    technologies: ["Next.js", "TypeScript"],
    githubUrl: "https://github.com/username/repo",
    liveUrl: "https://proyek.vercel.app",
  },
];
```

**Mengisi kontak** — edit `data/contact.ts`, isi `email` dan (opsional) `socials`.

## ☁️ Deployment ke Vercel

1. Push repository ini ke GitHub.
2. Buka [vercel.com/new](https://vercel.com/new), import repository.
3. Vercel akan mendeteksi Next.js secara otomatis — tidak ada environment variable yang dibutuhkan.
4. Deploy.

## 🗺️ Pengembangan Selanjutnya

- Mengisi `data/projects.ts` dengan proyek nyata
- Menambahkan section Fotografi kembali jika aktif memotret lagi
- Dark/light mode toggle (saat ini dark-only by design)
- i18n (ID/EN) jika dibutuhkan untuk audiens internasional

## 📄 Lisensi

MIT — bebas digunakan sebagai referensi, mohon tidak menyalin identik sebagai portofolio pribadi orang lain.

---

Designed & Developed by **Dimas**

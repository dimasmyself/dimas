import type { Metadata } from "next";
import { Inter, Space_Grotesk, JetBrains_Mono } from "next/font/google";
import { Navbar } from "@/components/sections/navbar";
import { Footer } from "@/components/sections/footer";
import "./globals.css";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const spaceGrotesk = Space_Grotesk({
  variable: "--font-space-grotesk",
  subsets: ["latin"],
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  variable: "--font-jetbrains-mono",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://dimas-portfolio.vercel.app"),
  title: "Dimas — Frontend Developer & AI Enthusiast",
  description:
    "Portofolio Dimas, pelajar yang tertarik pada Frontend Development, Artificial Intelligence, dan fotografi.",
  keywords: [
    "Dimas",
    "Frontend Developer",
    "AI Enthusiast",
    "Portfolio",
    "Web Developer Indonesia",
  ],
  openGraph: {
    title: "Dimas — Frontend Developer & AI Enthusiast",
    description:
      "Portofolio Dimas, pelajar yang tertarik pada Frontend Development, Artificial Intelligence, dan fotografi.",
    type: "website",
    locale: "id_ID",
  },
  twitter: {
    card: "summary_large_image",
    title: "Dimas — Frontend Developer & AI Enthusiast",
    description:
      "Portofolio Dimas, pelajar yang tertarik pada Frontend Development, Artificial Intelligence, dan fotografi.",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" className="dark">
      <body
        className={`${inter.variable} ${spaceGrotesk.variable} ${jetbrainsMono.variable} font-sans antialiased`}
      >
        <Navbar />
        {children}
        <Footer />
      </body>
    </html>
  );
}

"use client";

import { motion } from "framer-motion";
import { HorizonBackdrop } from "@/components/ui/horizon-backdrop";

const focusAreas = [
  {
    label: "Artificial Intelligence",
    detail: "Mempelajari cara kerja AI dan penerapannya pada produk nyata.",
  },
  {
    label: "Frontend Development",
    detail: "Merancang antarmuka yang bersih, responsif, dan terasa hidup.",
  },
  {
    label: "Fotografi",
    detail: "Melatih kepekaan terhadap komposisi, cahaya, dan momen.",
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] as const },
  },
};

export function About() {
  return (
    <section
      id="tentang"
      className="relative w-full overflow-hidden px-6 py-28 sm:px-10 sm:py-36 lg:px-16"
    >
      <HorizonBackdrop intensity="section" />

      <div className="relative z-10 mx-auto grid w-full max-w-5xl gap-16 lg:grid-cols-[0.9fr_1.1fr] lg:gap-12">
        {/* Left: eyebrow + heading */}
        <motion.div
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.4 }}
          variants={fadeUp}
        >
          <span className="font-mono text-xs tracking-widest text-[var(--emerald-soft)] uppercase">
            Tentang Saya
          </span>
          <h2 className="mt-4 font-[family-name:var(--font-display)] text-4xl leading-[1.05] tracking-tight sm:text-5xl">
            Rasa ingin tahu
            <br />
            sebagai titik awal.
          </h2>
        </motion.div>

        {/* Right: narrative + focus areas */}
        <div className="flex flex-col gap-10">
          <motion.p
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, amount: 0.4 }}
            variants={fadeUp}
            className="text-lg leading-relaxed text-[var(--text-muted)] sm:text-xl"
          >
            Saya seorang pelajar yang mulai mengenal dunia{" "}
            <span className="text-[var(--text-primary)]">
              Artificial Intelligence
            </span>
            , teknologi informasi, dan pengembangan website modern. Ketertarikan
            saya berpusat pada frontend development, AI, pengalaman pengguna,
            dan desain antarmuka yang modern — bagaimana sesuatu yang rumit bisa
            terasa sederhana dan menyenangkan untuk digunakan.
          </motion.p>

          <motion.p
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, amount: 0.4 }}
            variants={fadeUp}
            className="text-lg leading-relaxed text-[var(--text-muted)] sm:text-xl"
          >
            Di luar dunia teknologi, saya juga menyukai{" "}
            <span className="text-[var(--text-primary)]">fotografi</span>,{" "}
            <span className="text-[var(--text-primary)]">traveling</span>, dan
            eksplorasi tempat baru. Saya percaya belajar hal baru — baik lewat
            kode maupun lewat perjalanan — adalah cara terbaik untuk terus
            bertumbuh.
          </motion.p>

          <div className="grid gap-4 sm:grid-cols-3">
            {focusAreas.map((area, i) => (
              <motion.div
                key={area.label}
                initial="hidden"
                whileInView="show"
                viewport={{ once: true, amount: 0.4 }}
                variants={fadeUp}
                transition={{ delay: i * 0.1 }}
                className="glass-panel rounded-2xl p-5"
              >
                <p className="font-[family-name:var(--font-display)] text-base text-[var(--text-primary)]">
                  {area.label}
                </p>
                <p className="mt-2 text-sm leading-relaxed text-[var(--text-faint)]">
                  {area.detail}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

"use client";

import { motion } from "framer-motion";
import { Mail } from "lucide-react";
import { HorizonBackdrop } from "@/components/ui/horizon-backdrop";
import { MagneticButton } from "@/components/ui/magnetic-button";
import { email, socials } from "@/data/contact";

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] as const },
  },
};

export function Contact() {
  const hasEmail = email.trim().length > 0;

  return (
    <section
      id="kontak"
      className="relative w-full overflow-hidden px-6 py-28 sm:px-10 sm:py-36 lg:px-16"
    >
      <HorizonBackdrop intensity="section" />

      <div className="relative z-10 mx-auto flex w-full max-w-3xl flex-col items-center text-center">
        <motion.span
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.4 }}
          variants={fadeUp}
          className="font-mono text-xs tracking-widest text-[var(--emerald-soft)] uppercase"
        >
          Kontak
        </motion.span>

        <motion.h2
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.4 }}
          variants={fadeUp}
          transition={{ delay: 0.05 }}
          className="mt-4 font-[family-name:var(--font-display)] text-4xl leading-[1.05] tracking-tight sm:text-5xl"
        >
          Mari terhubung
          <br />
          <span className="text-gradient-horizon">dan berdiskusi.</span>
        </motion.h2>

        <motion.p
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.4 }}
          variants={fadeUp}
          transition={{ delay: 0.1 }}
          className="mt-6 max-w-md text-base leading-relaxed text-[var(--text-muted)]"
        >
          Terbuka untuk obrolan seputar frontend, AI, atau sekadar bertukar
          ide belajar.
        </motion.p>

        <motion.div
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.4 }}
          variants={fadeUp}
          transition={{ delay: 0.15 }}
          className="mt-10"
        >
          {hasEmail ? (
            <MagneticButton href={`mailto:${email}`} variant="primary">
              <Mail className="h-4 w-4" strokeWidth={1.75} />
              Kirim Email
            </MagneticButton>
          ) : (
            <div className="glass-panel rounded-2xl px-6 py-4 font-mono text-xs text-[var(--text-faint)]">
              Isi <code className="text-[var(--sky-soft)]">email</code> di{" "}
              <code className="text-[var(--sky-soft)]">data/contact.ts</code>{" "}
              untuk mengaktifkan tombol kontak.
            </div>
          )}
        </motion.div>

        {socials.length > 0 && (
          <motion.div
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, amount: 0.4 }}
            variants={fadeUp}
            transition={{ delay: 0.2 }}
            className="mt-8 flex items-center gap-3"
          >
            {socials.map((social) => {
              const Icon = social.icon;
              return (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={social.label}
                  className="glass-panel flex h-11 w-11 items-center justify-center rounded-full text-[var(--text-muted)] transition-colors hover:border-[var(--glass-border-strong)] hover:text-[var(--text-primary)]"
                >
                  <Icon className="h-4 w-4" strokeWidth={1.75} />
                </a>
              );
            })}
          </motion.div>
        )}
      </div>
    </section>
  );
}

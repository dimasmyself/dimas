export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="relative w-full border-t border-[var(--glass-border)] px-6 py-10 sm:px-10 lg:px-16">
      <div className="mx-auto flex w-full max-w-5xl flex-col items-center justify-between gap-4 sm:flex-row">
        <p className="font-mono text-xs text-[var(--text-faint)]">
          Designed &amp; Developed by{" "}
          <span className="text-[var(--text-muted)]">Dimas</span>
        </p>
        <p className="font-mono text-xs text-[var(--text-faint)]">
          &copy; {year}. Dibangun dengan Next.js &amp; Tailwind CSS.
        </p>
      </div>
    </footer>
  );
}

"use client";

import { motion } from "framer-motion";
import { ArrowDown } from "lucide-react";
import { HorizonBackdrop } from "@/components/ui/horizon-backdrop";
import { MagneticButton } from "@/components/ui/magnetic-button";

const roles = [
  "Pelajar",
  "Frontend Developer",
  "AI Enthusiast",
  "Photography Enthusiast",
];

const container = {
  hidden: {},
  show: {
    transition: { staggerChildren: 0.09, delayChildren: 0.15 },
  },
};

const item = {
  hidden: { opacity: 0, y: 22, filter: "blur(8px)" },
  show: {
    opacity: 1,
    y: 0,
    filter: "blur(0px)",
    transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] as const },
  },
};

export function Hero() {
  return (
    <section
      id="beranda"
      className="relative flex min-h-[100svh] w-full flex-col justify-center overflow-hidden px-6 sm:px-10 lg:px-16"
    >
      <HorizonBackdrop intensity="hero" />

      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="relative z-10 mx-auto flex w-full max-w-5xl flex-col items-start"
      >
        <motion.span
          variants={item}
          className="mb-6 inline-flex items-center gap-2 rounded-full px-4 py-1.5 font-mono text-xs tracking-wide text-[var(--text-muted)] glass-panel"
        >
          <span
            className="h-1.5 w-1.5 rounded-full bg-[var(--emerald)]"
            style={{ boxShadow: "0 0 8px var(--emerald)" }}
          />
          Terbuka untuk kolaborasi & belajar bersama
        </motion.span>

        <motion.h1
          variants={item}
          className="font-[family-name:var(--font-display)] text-[13vw] leading-[0.95] tracking-tight sm:text-[9vw] lg:text-[6.2vw]"
        >
          Membangun
          <br />
          <span className="text-gradient-horizon">antarmuka</span> yang
          <br />
          terasa hidup.
        </motion.h1>

        <motion.p
          variants={item}
          className="mt-8 max-w-xl text-lg leading-relaxed text-[var(--text-muted)] sm:text-xl"
        >
          Saya <span className="text-[var(--text-primary)]">Dimas</span> —
          menggabungkan ketertarikan pada{" "}
          <span className="text-[var(--text-primary)]">
            kecerdasan buatan
          </span>{" "}
          dan{" "}
          <span className="text-[var(--text-primary)]">
            pengembangan web
          </span>{" "}
          untuk merancang pengalaman digital yang bersih, cepat, dan
          bermakna.
        </motion.p>

        <motion.div
          variants={item}
          className="mt-6 flex flex-wrap items-center gap-x-3 gap-y-2 font-mono text-xs text-[var(--text-faint)]"
        >
          {roles.map((role, i) => (
            <span key={role} className="flex items-center gap-3">
              <span>{role}</span>
              {i < roles.length - 1 && (
                <span className="text-[var(--glass-border-strong)]">/</span>
              )}
            </span>
          ))}
        </motion.div>

        <motion.div
          variants={item}
          className="mt-12 flex flex-wrap items-center gap-4"
        >
          <MagneticButton href="#proyek" variant="primary">
            Lihat Proyek
          </MagneticButton>
          <MagneticButton href="#kontak" variant="ghost">
            Hubungi Saya
          </MagneticButton>
        </motion.div>
      </motion.div>

      <motion.a
        href="#tentang"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.1, duration: 0.6 }}
        className="absolute bottom-10 left-1/2 z-10 flex -translate-x-1/2 flex-col items-center gap-2 text-[var(--text-faint)] transition-colors hover:text-[var(--text-muted)]"
        aria-label="Gulir ke bagian Tentang Saya"
      >
        <span className="font-mono text-[10px] tracking-widest uppercase">
          Scroll
        </span>
        <motion.span
          animate={{ y: [0, 6, 0] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
        >
          <ArrowDown className="h-4 w-4" />
        </motion.span>
      </motion.a>
    </section>
  );
}

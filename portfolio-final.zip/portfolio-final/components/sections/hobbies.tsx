"use client";

import { motion } from "framer-motion";
import { Plane, Camera, Compass, Sparkles } from "lucide-react";
import { HorizonBackdrop } from "@/components/ui/horizon-backdrop";

const hobbies = [
  {
    icon: Plane,
    label: "Traveling",
    detail: "Menikmati perjalanan sebagai cara memahami sudut pandang baru.",
  },
  {
    icon: Camera,
    label: "Photography",
    detail: "Melatih kepekaan terhadap komposisi, cahaya, dan momen.",
  },
  {
    icon: Compass,
    label: "Exploring New Places",
    detail: "Senang menyusuri tempat yang belum pernah dikunjungi.",
  },
  {
    icon: Sparkles,
    label: "Learning New Technologies",
    detail: "Selalu tertarik mencoba tools dan pendekatan baru.",
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] as const },
  },
};

export function Hobbies() {
  return (
    <section
      id="hobi"
      className="relative w-full overflow-hidden px-6 py-28 sm:px-10 sm:py-36 lg:px-16"
    >
      <HorizonBackdrop intensity="section" />

      <div className="relative z-10 mx-auto w-full max-w-5xl">
        <motion.div
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.4 }}
          variants={fadeUp}
          className="max-w-xl"
        >
          <span className="font-mono text-xs tracking-widest text-[var(--emerald-soft)] uppercase">
            Di Luar Layar
          </span>
          <h2 className="mt-4 font-[family-name:var(--font-display)] text-4xl leading-[1.05] tracking-tight sm:text-5xl">
            Hal-hal yang
            <br />
            saya nikmati.
          </h2>
        </motion.div>

        <div className="mt-16 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {hobbies.map((hobby, i) => {
            const Icon = hobby.icon;
            return (
              <motion.div
                key={hobby.label}
                initial="hidden"
                whileInView="show"
                viewport={{ once: true, amount: 0.3 }}
                variants={fadeUp}
                transition={{ delay: i * 0.08 }}
                whileHover={{ y: -4 }}
                className="group glass-panel relative overflow-hidden rounded-3xl p-6 transition-[border-color] duration-300 hover:border-[var(--glass-border-strong)]"
              >
                <div
                  className="pointer-events-none absolute -top-14 -right-14 h-32 w-32 rounded-full opacity-0 blur-3xl transition-opacity duration-500 group-hover:opacity-100"
                  style={{
                    background:
                      i % 2 === 0
                        ? "rgba(94,200,242,0.16)"
                        : "rgba(52,216,166,0.16)",
                  }}
                  aria-hidden="true"
                />
                <div className="relative z-10 flex h-11 w-11 items-center justify-center rounded-2xl border border-[var(--glass-border)] bg-[var(--bg-elevated)]">
                  <Icon
                    className="h-5 w-5 text-[var(--sky-soft)]"
                    strokeWidth={1.75}
                  />
                </div>
                <p className="relative z-10 mt-5 font-[family-name:var(--font-display)] text-base text-[var(--text-primary)]">
                  {hobby.label}
                </p>
                <p className="relative z-10 mt-2 text-sm leading-relaxed text-[var(--text-faint)]">
                  {hobby.detail}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

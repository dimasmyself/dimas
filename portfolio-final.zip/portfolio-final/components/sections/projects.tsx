"use client";

import { motion } from "framer-motion";
import { HorizonBackdrop } from "@/components/ui/horizon-backdrop";
import { ProjectCard } from "@/components/ui/project-card";
import { ProjectsEmptyState } from "@/components/ui/projects-empty-state";
import { projects } from "@/data/projects";

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] as const },
  },
};

export function Projects() {
  const hasProjects = projects.length > 0;

  return (
    <section
      id="proyek"
      className="relative w-full overflow-hidden px-6 py-28 sm:px-10 sm:py-36 lg:px-16"
    >
      <HorizonBackdrop intensity="section" />

      <div className="relative z-10 mx-auto w-full max-w-5xl">
        <motion.div
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.4 }}
          variants={fadeUp}
          className="max-w-xl"
        >
          <span className="font-mono text-xs tracking-widest text-[var(--emerald-soft)] uppercase">
            Proyek
          </span>
          <h2 className="mt-4 font-[family-name:var(--font-display)] text-4xl leading-[1.05] tracking-tight sm:text-5xl">
            Hal-hal yang
            <br />
            sedang dibangun.
          </h2>
        </motion.div>

        <div className="mt-16">
          {hasProjects ? (
            <div className="grid gap-6 sm:grid-cols-2">
              {projects.map((project, i) => (
                <ProjectCard key={project.slug} project={project} index={i} />
              ))}
            </div>
          ) : (
            <ProjectsEmptyState />
          )}
        </div>
      </div>
    </section>
  );
}

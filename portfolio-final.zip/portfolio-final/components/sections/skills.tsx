"use client";

import { motion } from "framer-motion";
import {
  Code2,
  BrainCircuit,
  Wrench,
  Sprout,
} from "lucide-react";
import { HorizonBackdrop } from "@/components/ui/horizon-backdrop";

interface SkillGroup {
  icon: typeof Code2;
  label: string;
  note: string;
  items: string[];
}

const skillGroups: SkillGroup[] = [
  {
    icon: Code2,
    label: "Frontend",
    note: "Membangun antarmuka",
    items: [
      "Frontend Development",
      "Responsive Web Design",
      "UI Implementation",
    ],
  },
  {
    icon: BrainCircuit,
    label: "Artificial Intelligence",
    note: "Eksplorasi & penerapan",
    items: ["Artificial Intelligence"],
  },
  {
    icon: Wrench,
    label: "Tools",
    note: "Alat kerja sehari-hari",
    items: ["Git & GitHub", "Problem Solving"],
  },
  {
    icon: Sprout,
    label: "Currently Learning",
    note: "Sedang didalami",
    items: ["Backend Development", "Cloud", "Performance Optimization"],
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] as const },
  },
};

export function Skills() {
  return (
    <section
      id="keahlian"
      className="relative w-full overflow-hidden px-6 py-28 sm:px-10 sm:py-36 lg:px-16"
    >
      <HorizonBackdrop intensity="section" />

      <div className="relative z-10 mx-auto w-full max-w-5xl">
        <motion.div
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.4 }}
          variants={fadeUp}
          className="max-w-xl"
        >
          <span className="font-mono text-xs tracking-widest text-[var(--emerald-soft)] uppercase">
            Keahlian
          </span>
          <h2 className="mt-4 font-[family-name:var(--font-display)] text-4xl leading-[1.05] tracking-tight sm:text-5xl">
            Alat dan area
            <br />
            yang saya dalami.
          </h2>
        </motion.div>

        <div className="mt-16 grid gap-5 sm:grid-cols-2">
          {skillGroups.map((group, i) => {
            const Icon = group.icon;
            return (
              <motion.div
                key={group.label}
                initial="hidden"
                whileInView="show"
                viewport={{ once: true, amount: 0.3 }}
                variants={fadeUp}
                transition={{ delay: i * 0.08 }}
                whileHover={{ y: -4 }}
                className="group glass-panel relative overflow-hidden rounded-3xl p-7 transition-[border-color] duration-300 hover:border-[var(--glass-border-strong)]"
              >
                {/* Hover glow */}
                <div
                  className="pointer-events-none absolute -top-16 -right-16 h-40 w-40 rounded-full opacity-0 blur-3xl transition-opacity duration-500 group-hover:opacity-100"
                  style={{
                    background:
                      i % 2 === 0
                        ? "rgba(94,200,242,0.18)"
                        : "rgba(52,216,166,0.18)",
                  }}
                  aria-hidden="true"
                />

                <div className="relative z-10 flex items-start justify-between">
                  <div className="flex h-11 w-11 items-center justify-center rounded-2xl border border-[var(--glass-border)] bg-[var(--bg-elevated)]">
                    <Icon
                      className="h-5 w-5 text-[var(--sky-soft)]"
                      strokeWidth={1.75}
                    />
                  </div>
                  <span className="font-mono text-[10px] tracking-widest text-[var(--text-faint)] uppercase">
                    {group.note}
                  </span>
                </div>

                <h3 className="relative z-10 mt-6 font-[family-name:var(--font-display)] text-xl text-[var(--text-primary)]">
                  {group.label}
                </h3>

                <ul className="relative z-10 mt-5 flex flex-wrap gap-2">
                  {group.items.map((skill) => (
                    <li
                      key={skill}
                      className="rounded-full border border-[var(--glass-border)] bg-[var(--bg-elevated)] px-3.5 py-1.5 text-sm text-[var(--text-muted)] transition-colors group-hover:border-[var(--glass-border-strong)]"
                    >
                      {skill}
                    </li>
                  ))}
                </ul>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

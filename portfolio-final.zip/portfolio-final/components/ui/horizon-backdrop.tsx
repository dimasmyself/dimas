import { cn } from "@/lib/utils";

interface HorizonBackdropProps {
  className?: string;
  intensity?: "hero" | "section";
}

/**
 * Signature ambient layer: a thin sky→emerald horizon line with soft bloom,
 * a faint technical grid, and drifting glass glows. Used behind the Hero at
 * full intensity, and as a quieter divider echo in later sections.
 */
export function HorizonBackdrop({
  className,
  intensity = "section",
}: HorizonBackdropProps) {
  const isHero = intensity === "hero";

  return (
    <div
      className={cn(
        "pointer-events-none absolute inset-0 overflow-hidden",
        className
      )}
      aria-hidden="true"
    >
      {/* Base grid */}
      <div
        className="absolute inset-0 opacity-[0.05]"
        style={{
          backgroundImage:
            "linear-gradient(var(--glass-border-strong) 1px, transparent 1px), linear-gradient(90deg, var(--glass-border-strong) 1px, transparent 1px)",
          backgroundSize: "64px 64px",
          maskImage:
            "radial-gradient(ellipse 80% 60% at 50% 40%, black 40%, transparent 100%)",
        }}
      />

      {/* Horizon glow — sits at ~62% height */}
      <div
        className="absolute left-1/2 top-[58%] h-px w-[140%] -translate-x-1/2"
        style={{
          background:
            "linear-gradient(90deg, transparent 0%, var(--sky) 20%, var(--emerald-soft) 50%, var(--sky) 80%, transparent 100%)",
          opacity: isHero ? 0.55 : 0.25,
        }}
      />
      <div
        className="absolute left-1/2 top-[58%] h-40 w-[140%] -translate-x-1/2 -translate-y-1/2 blur-3xl"
        style={{
          background:
            "linear-gradient(90deg, transparent 10%, rgba(94,200,242,0.25) 35%, rgba(52,216,166,0.25) 65%, transparent 90%)",
          opacity: isHero ? 1 : 0.4,
        }}
      />

      {/* Reflection bloom below horizon */}
      {isHero && (
        <div
          className="absolute left-1/2 top-[58%] h-64 w-[80%] -translate-x-1/2"
          style={{
            background:
              "linear-gradient(180deg, rgba(94,200,242,0.08) 0%, transparent 100%)",
            filter: "blur(40px)",
          }}
        />
      )}

      {/* Drifting soft orbs */}
      <div
        className="absolute -top-24 left-[15%] h-72 w-72 rounded-full blur-[100px]"
        style={{ background: "rgba(94,200,242,0.14)" }}
      />
      <div
        className="absolute top-[10%] right-[10%] h-96 w-96 rounded-full blur-[120px]"
        style={{ background: "rgba(52,216,166,0.10)" }}
      />
    </div>
  );
}

"use client";

import { motion } from "framer-motion";
import { ArrowUpRight, FolderGit2 } from "lucide-react";
import type { Project } from "@/data/projects";

interface ProjectCardProps {
  project: Project;
  index: number;
}

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] as const },
  },
};

export function ProjectCard({ project, index }: ProjectCardProps) {
  return (
    <motion.article
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, amount: 0.3 }}
      variants={fadeUp}
      transition={{ delay: index * 0.08 }}
      whileHover={{ y: -6 }}
      className="group glass-panel relative flex flex-col overflow-hidden rounded-3xl transition-[border-color] duration-300 hover:border-[var(--glass-border-strong)]"
    >
      <div
        className="pointer-events-none absolute -top-20 -right-20 h-48 w-48 rounded-full opacity-0 blur-3xl transition-opacity duration-500 group-hover:opacity-100"
        style={{
          background:
            index % 2 === 0
              ? "rgba(94,200,242,0.18)"
              : "rgba(52,216,166,0.18)",
        }}
        aria-hidden="true"
      />

      {project.previewImage ? (
        <div className="relative aspect-video w-full overflow-hidden border-b border-[var(--glass-border)]">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={project.previewImage}
            alt={`Preview ${project.title}`}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        </div>
      ) : (
        <div className="relative flex aspect-video w-full items-center justify-center border-b border-[var(--glass-border)] bg-[var(--bg-elevated)]">
          <span className="font-mono text-xs tracking-widest text-[var(--text-faint)] uppercase">
            {project.title}
          </span>
        </div>
      )}

      <div className="relative z-10 flex flex-1 flex-col p-7">
        <h3 className="font-[family-name:var(--font-display)] text-xl text-[var(--text-primary)]">
          {project.title}
        </h3>
        <p className="mt-3 flex-1 text-sm leading-relaxed text-[var(--text-muted)]">
          {project.description}
        </p>

        <ul className="mt-5 flex flex-wrap gap-2">
          {project.technologies.map((tech) => (
            <li
              key={tech}
              className="rounded-full border border-[var(--glass-border)] bg-[var(--bg-elevated)] px-3 py-1 font-mono text-[11px] text-[var(--text-muted)]"
            >
              {tech}
            </li>
          ))}
        </ul>

        <div className="mt-6 flex items-center gap-4 border-t border-[var(--glass-border)] pt-5">
          {project.githubUrl && (
            <a
              href={project.githubUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-sm text-[var(--text-muted)] transition-colors hover:text-[var(--text-primary)]"
            >
              <FolderGit2 className="h-4 w-4" strokeWidth={1.75} />
              Kode
            </a>
          )}
          {project.liveUrl && (
            <a
              href={project.liveUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-sm text-[var(--text-muted)] transition-colors hover:text-[var(--text-primary)]"
            >
              <ArrowUpRight className="h-4 w-4" strokeWidth={1.75} />
              Live Demo
            </a>
          )}
          {project.caseStudyUrl && (
            <a
              href={project.caseStudyUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-sm text-[var(--text-muted)] transition-colors hover:text-[var(--text-primary)]"
            >
              Case Study
            </a>
          )}
        </div>
      </div>
    </motion.article>
  );
}

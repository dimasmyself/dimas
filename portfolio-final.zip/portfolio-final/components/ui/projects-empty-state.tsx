"use client";

import { motion } from "framer-motion";
import { Hammer } from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] as const },
  },
};

export function ProjectsEmptyState() {
  return (
    <motion.div
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, amount: 0.4 }}
      variants={fadeUp}
      className="glass-panel relative mx-auto flex max-w-xl flex-col items-center gap-5 overflow-hidden rounded-3xl px-8 py-16 text-center"
    >
      <div
        className="pointer-events-none absolute -top-24 left-1/2 h-56 w-56 -translate-x-1/2 rounded-full blur-3xl"
        style={{ background: "rgba(94,200,242,0.14)" }}
        aria-hidden="true"
      />

      <div className="relative z-10 flex h-12 w-12 items-center justify-center rounded-2xl border border-[var(--glass-border)] bg-[var(--bg-elevated)]">
        <Hammer className="h-5 w-5 text-[var(--sky-soft)]" strokeWidth={1.75} />
      </div>

      <p className="relative z-10 font-[family-name:var(--font-display)] text-xl text-[var(--text-primary)]">
        Proyek akan segera ditambahkan
      </p>
      <p className="relative z-10 max-w-sm text-sm leading-relaxed text-[var(--text-muted)]">
        Saya sedang menyusun proyek-proyek untuk ditampilkan di sini. Kembali
        lagi dalam waktu dekat.
      </p>
    </motion.div>
  );
}

import type { LucideIcon } from "lucide-react";
import { ExternalLink, FolderGit2, Mail } from "lucide-react";

export interface ContactLink {
  label: string;
  href: string;
  icon: LucideIcon;
}

/**
 * Isi email dan tautan sosial di sini. Kosongkan array `socials` jika
 * belum ingin menampilkan tautan sosial media.
 *
 * Contoh menambah tautan (gunakan FolderGit2 untuk GitHub, ExternalLink
 * untuk platform lain — lucide-react versi ini tidak menyertakan ikon
 * merek/brand):
 * { label: "GitHub", href: "https://github.com/username", icon: FolderGit2 }
 */
export const email = "";

export const socials: ContactLink[] = [
  // { label: "GitHub", href: "https://github.com/username", icon: FolderGit2 },
  // { label: "LinkedIn", href: "https://linkedin.com/in/username", icon: ExternalLink },
  // { label: "Instagram", href: "https://instagram.com/username", icon: ExternalLink },
];

export const contactIcons = { FolderGit2, ExternalLink, Mail };

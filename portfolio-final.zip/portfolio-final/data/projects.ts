export interface Project {
  slug: string;
  title: string;
  description: string;
  technologies: string[];
  githubUrl?: string;
  liveUrl?: string;
  caseStudyUrl?: string;
  previewImage?: string;
}

/**
 * Tambahkan proyek di sini. Contoh:
 *
 * {
 *   slug: "nama-proyek",
 *   title: "Nama Proyek",
 *   description: "Deskripsi singkat proyek.",
 *   technologies: ["Next.js", "TypeScript"],
 *   githubUrl: "https://github.com/username/repo",
 *   liveUrl: "https://proyek.vercel.app",
 * }
 */
export const projects: Project[] = [];
